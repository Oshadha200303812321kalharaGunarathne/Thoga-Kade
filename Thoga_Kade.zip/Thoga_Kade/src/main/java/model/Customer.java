package model;

import lombok.*;

import java.time.LocalDate;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString

public class Customer {

    private String custID;
    private String title;
    private String name;
    private LocalDate DOB;
    private double salary;
    private String address;
    private String city;
    private String province;
    private String postalCode;
}
